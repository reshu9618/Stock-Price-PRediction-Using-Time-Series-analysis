import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const symbol = searchParams.get("symbol") || "AAPL"

  try {
    // Mock stock data - replace with actual API call
    const mockData = {
      symbol,
      data: Array.from({ length: 100 }, (_, i) => ({
        date: new Date(Date.now() - (99 - i) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        open: 150 + Math.random() * 20 - 10,
        high: 155 + Math.random() * 20 - 10,
        low: 145 + Math.random() * 20 - 10,
        close: 150 + Math.random() * 20 - 10,
        volume: Math.floor(Math.random() * 1000000) + 500000,
      })),
    }

    return NextResponse.json(mockData)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch stock data" }, { status: 500 })
  }
}
