import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { symbol, days } = await request.json()

    // Mock model comparison results
    const comparison = {
      symbol,
      days,
      models: {
        xgboost: {
          accuracy: 0.89,
          mse: 2.45,
          mae: 1.23,
          r2_score: 0.87,
          execution_time: 0.12,
          prediction: 155.3,
          features_importance: {
            close_price: 0.35,
            volume: 0.2,
            moving_avg_20: 0.15,
            rsi: 0.12,
            macd: 0.1,
            bollinger_bands: 0.08,
          },
        },
        catboost: {
          accuracy: 0.91,
          mse: 2.12,
          mae: 1.15,
          r2_score: 0.89,
          execution_time: 0.18,
          prediction: 157.85,
          features_importance: {
            close_price: 0.32,
            volume: 0.22,
            moving_avg_20: 0.18,
            rsi: 0.11,
            macd: 0.09,
            bollinger_bands: 0.08,
          },
        },
        voting: {
          accuracy: 0.87,
          mse: 2.78,
          mae: 1.34,
          r2_score: 0.85,
          execution_time: 0.25,
          prediction: 154.2,
          features_importance: {
            close_price: 0.3,
            volume: 0.25,
            moving_avg_20: 0.2,
            rsi: 0.1,
            macd: 0.08,
            bollinger_bands: 0.07,
          },
        },
        ensemble: {
          accuracy: 0.93,
          mse: 1.89,
          mae: 1.05,
          r2_score: 0.91,
          execution_time: 0.35,
          prediction: 158.75,
          features_importance: {
            close_price: 0.33,
            volume: 0.21,
            moving_avg_20: 0.17,
            rsi: 0.12,
            macd: 0.09,
            bollinger_bands: 0.08,
          },
        },
      },
      best_model: "ensemble",
      timestamp: new Date().toISOString(),
    }

    return NextResponse.json(comparison)
  } catch (error) {
    return NextResponse.json({ error: "Model comparison failed" }, { status: 500 })
  }
}
