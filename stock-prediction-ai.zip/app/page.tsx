"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Brain, BarChart3, Activity } from "lucide-react"
import StockChart from "@/components/stock-chart"
import PredictionResults from "@/components/prediction-results"
import ModelComparison from "@/components/model-comparison"

export default function StockPredictionDashboard() {
  const [symbol, setSymbol] = useState("AAPL")
  const [predictionDays, setPredictionDays] = useState("30")
  const [selectedModel, setSelectedModel] = useState("ensemble")
  const [isLoading, setIsLoading] = useState(false)
  const [predictions, setPredictions] = useState(null)
  const [historicalData, setHistoricalData] = useState(null)

  const handlePredict = async () => {
    setIsLoading(true)
    try {
      // Fetch historical data
      const historyResponse = await fetch(`/api/stock-data?symbol=${symbol}`)
      const historyData = await historyResponse.json()
      setHistoricalData(historyData)

      // Get predictions from selected model
      const predictionResponse = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol,
          days: Number.parseInt(predictionDays),
          model: selectedModel,
        }),
      })
      const predictionData = await predictionResponse.json()
      setPredictions(predictionData)
    } catch (error) {
      console.error("Prediction error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900 flex items-center justify-center gap-3">
            <Brain className="h-10 w-10 text-blue-600" />
            AI Stock Price Predictor
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Advanced time series analysis using XGBoost, CatBoost, Voting Regressor, and ensemble methods
          </p>
          <div className="flex justify-center gap-2">
            <Badge variant="secondary">XGBoost</Badge>
            <Badge variant="secondary">CatBoost</Badge>
            <Badge variant="secondary">Voting Regressor</Badge>
            <Badge variant="secondary">Ensemble</Badge>
          </div>
        </div>

        {/* Prediction Form */}
        <Card className="w-full max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Stock Prediction Configuration
            </CardTitle>
            <CardDescription>Configure your stock prediction parameters and select ML model</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="symbol">Stock Symbol</Label>
                <Input
                  id="symbol"
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                  placeholder="e.g., AAPL, GOOGL, TSLA"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="days">Prediction Days</Label>
                <Select value={predictionDays} onValueChange={setPredictionDays}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 Days</SelectItem>
                    <SelectItem value="14">14 Days</SelectItem>
                    <SelectItem value="30">30 Days</SelectItem>
                    <SelectItem value="60">60 Days</SelectItem>
                    <SelectItem value="90">90 Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="model">ML Model</Label>
                <Select value={selectedModel} onValueChange={setSelectedModel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="xgboost">XGBoost</SelectItem>
                    <SelectItem value="catboost">CatBoost</SelectItem>
                    <SelectItem value="voting">Voting Regressor</SelectItem>
                    <SelectItem value="ensemble">Ensemble (All Models)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handlePredict} disabled={isLoading} className="w-full" size="lg">
              {isLoading ? (
                <>
                  <Activity className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing & Predicting...
                </>
              ) : (
                <>
                  <Brain className="mr-2 h-4 w-4" />
                  Generate Predictions
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {(predictions || historicalData) && (
          <Tabs defaultValue="chart" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="chart">Price Chart</TabsTrigger>
              <TabsTrigger value="predictions">Predictions</TabsTrigger>
              <TabsTrigger value="comparison">Model Comparison</TabsTrigger>
            </TabsList>

            <TabsContent value="chart" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Stock Price Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <StockChart historicalData={historicalData} predictions={predictions} symbol={symbol} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="predictions" className="space-y-4">
              <PredictionResults predictions={predictions} symbol={symbol} model={selectedModel} />
            </TabsContent>

            <TabsContent value="comparison" className="space-y-4">
              <ModelComparison symbol={symbol} days={predictionDays} />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  )
}
