// Data processing utilities for stock prediction
import fs from "fs"

class StockDataProcessor {
  constructor() {
    this.data = []
    this.features = []
  }

  // Load stock data from various sources
  async loadData(source, symbol) {
    console.log(`Loading data for ${symbol} from ${source}...`)

    // Mock data loading - replace with actual API calls
    const mockData = this.generateMockData(symbol, 1000)
    this.data = mockData

    console.log(`Loaded ${this.data.length} data points`)
    return this.data
  }

  // Generate mock stock data for testing
  generateMockData(symbol, count) {
    const data = []
    let price = 100 + Math.random() * 100

    for (let i = 0; i < count; i++) {
      const date = new Date()
      date.setDate(date.getDate() - (count - i))

      // Simulate price movement
      const change = (Math.random() - 0.5) * 5
      price += change

      const high = price + Math.random() * 3
      const low = price - Math.random() * 3
      const volume = Math.floor(Math.random() * 1000000) + 500000

      data.push({
        date: date.toISOString().split("T")[0],
        open: price - change,
        high: Math.max(high, price),
        low: Math.min(low, price),
        close: price,
        volume: volume,
      })
    }

    return data
  }

  // Calculate technical indicators
  calculateTechnicalIndicators() {
    console.log("Calculating technical indicators...")

    const prices = this.data.map((d) => d.close)
    const volumes = this.data.map((d) => d.volume)

    // Moving averages
    const ma5 = this.calculateMovingAverage(prices, 5)
    const ma10 = this.calculateMovingAverage(prices, 10)
    const ma20 = this.calculateMovingAverage(prices, 20)
    const ma50 = this.calculateMovingAverage(prices, 50)

    // RSI
    const rsi = this.calculateRSI(prices, 14)

    // MACD
    const macd = this.calculateMACD(prices)

    // Bollinger Bands
    const bollinger = this.calculateBollingerBands(prices, 20, 2)

    // Add indicators to data
    this.data.forEach((item, index) => {
      item.ma5 = ma5[index]
      item.ma10 = ma10[index]
      item.ma20 = ma20[index]
      item.ma50 = ma50[index]
      item.rsi = rsi[index]
      item.macd = macd[index]
      item.bollinger_upper = bollinger.upper[index]
      item.bollinger_lower = bollinger.lower[index]
      item.bollinger_middle = bollinger.middle[index]
    })

    console.log("Technical indicators calculated")
    return this.data
  }

  // Calculate moving average
  calculateMovingAverage(data, period) {
    const result = []
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) {
        result.push(null)
      } else {
        const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0)
        result.push(sum / period)
      }
    }
    return result
  }

  // Calculate RSI
  calculateRSI(prices, period = 14) {
    const gains = []
    const losses = []

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1]
      gains.push(change > 0 ? change : 0)
      losses.push(change < 0 ? Math.abs(change) : 0)
    }

    const rsi = []
    rsi.push(null) // First value is null

    for (let i = period - 1; i < gains.length; i++) {
      const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
      const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period

      if (avgLoss === 0) {
        rsi.push(100)
      } else {
        const rs = avgGain / avgLoss
        rsi.push(100 - 100 / (1 + rs))
      }
    }

    // Fill remaining with null
    while (rsi.length < prices.length) {
      rsi.unshift(null)
    }

    return rsi
  }

  // Calculate MACD
  calculateMACD(prices, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
    const emaFast = this.calculateEMA(prices, fastPeriod)
    const emaSlow = this.calculateEMA(prices, slowPeriod)

    const macdLine = emaFast.map((fast, i) => {
      if (fast === null || emaSlow[i] === null) return null
      return fast - emaSlow[i]
    })

    return macdLine
  }

  // Calculate EMA
  calculateEMA(data, period) {
    const multiplier = 2 / (period + 1)
    const ema = []

    ema[0] = data[0]

    for (let i = 1; i < data.length; i++) {
      ema[i] = data[i] * multiplier + ema[i - 1] * (1 - multiplier)
    }

    return ema
  }

  // Calculate Bollinger Bands
  calculateBollingerBands(prices, period = 20, multiplier = 2) {
    const ma = this.calculateMovingAverage(prices, period)
    const upper = []
    const lower = []
    const middle = []

    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        upper.push(null)
        lower.push(null)
        middle.push(null)
      } else {
        const slice = prices.slice(i - period + 1, i + 1)
        const mean = ma[i]
        const variance = slice.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / period
        const stdDev = Math.sqrt(variance)

        upper.push(mean + stdDev * multiplier)
        lower.push(mean - stdDev * multiplier)
        middle.push(mean)
      }
    }

    return { upper, lower, middle }
  }

  // Prepare features for ML models
  prepareFeatures() {
    console.log("Preparing features for ML models...")

    const features = []

    this.data.forEach((item, index) => {
      if (index === 0) return // Skip first item due to price change calculation

      const prevItem = this.data[index - 1]

      features.push({
        // Price features
        close: item.close,
        open: item.open,
        high: item.high,
        low: item.low,
        volume: item.volume,

        // Derived features
        price_change: (item.close - prevItem.close) / prevItem.close,
        volume_change: (item.volume - prevItem.volume) / prevItem.volume,
        high_low_ratio: item.high / item.low,
        open_close_ratio: item.open / item.close,

        // Technical indicators
        ma5: item.ma5,
        ma10: item.ma10,
        ma20: item.ma20,
        ma50: item.ma50,
        rsi: item.rsi,
        macd: item.macd,
        bollinger_upper: item.bollinger_upper,
        bollinger_lower: item.bollinger_lower,
        bollinger_position:
          item.bollinger_upper && item.bollinger_lower
            ? (item.close - item.bollinger_lower) / (item.bollinger_upper - item.bollinger_lower)
            : null,

        // Date features
        day_of_week: new Date(item.date).getDay(),
        month: new Date(item.date).getMonth(),

        // Target (next day's closing price)
        target: index < this.data.length - 1 ? this.data[index + 1].close : null,
      })
    })

    // Remove entries with null values
    this.features = features.filter((f) => f.ma20 !== null && f.rsi !== null && f.target !== null)

    console.log(`Prepared ${this.features.length} feature vectors`)
    return this.features
  }

  // Export data for Python ML models
  exportForML(filename = "stock_features.json") {
    const exportData = {
      symbol: "STOCK",
      features: this.features,
      feature_names: Object.keys(this.features[0] || {}),
      timestamp: new Date().toISOString(),
    }

    fs.writeFileSync(filename, JSON.stringify(exportData, null, 2))
    console.log(`Data exported to ${filename}`)

    return exportData
  }

  // Calculate correlation matrix
  calculateCorrelations() {
    if (this.features.length === 0) {
      console.log("No features available for correlation analysis")
      return null
    }

    const numericFeatures = ["close", "volume", "price_change", "rsi", "ma20"]
    const correlations = {}

    numericFeatures.forEach((feature1) => {
      correlations[feature1] = {}
      numericFeatures.forEach((feature2) => {
        const values1 = this.features.map((f) => f[feature1]).filter((v) => v !== null)
        const values2 = this.features.map((f) => f[feature2]).filter((v) => v !== null)

        correlations[feature1][feature2] = this.pearsonCorrelation(values1, values2)
      })
    })

    console.log("Correlation matrix calculated")
    return correlations
  }

  // Calculate Pearson correlation coefficient
  pearsonCorrelation(x, y) {
    const n = Math.min(x.length, y.length)
    if (n === 0) return 0

    const sumX = x.slice(0, n).reduce((a, b) => a + b, 0)
    const sumY = y.slice(0, n).reduce((a, b) => a + b, 0)
    const sumXY = x.slice(0, n).reduce((sum, xi, i) => sum + xi * y[i], 0)
    const sumX2 = x.slice(0, n).reduce((sum, xi) => sum + xi * xi, 0)
    const sumY2 = y.slice(0, n).reduce((sum, yi) => sum + yi * yi, 0)

    const numerator = n * sumXY - sumX * sumY
    const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY))

    return denominator === 0 ? 0 : numerator / denominator
  }
}

// Example usage
async function main() {
  const processor = new StockDataProcessor()

  // Load and process data
  await processor.loadData("mock", "AAPL")
  processor.calculateTechnicalIndicators()
  processor.prepareFeatures()

  // Export for ML
  processor.exportForML("aapl_features.json")

  // Calculate correlations
  const correlations = processor.calculateCorrelations()
  console.log("Feature correlations:", correlations)

  console.log("Data processing completed!")
}

// Run if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error)
}

export default StockDataProcessor
