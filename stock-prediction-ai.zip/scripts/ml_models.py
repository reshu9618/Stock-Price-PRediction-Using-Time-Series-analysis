import numpy as np
import pandas as pd
from sklearn.ensemble import VotingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
import xgboost as xgb
# Note: CatBoost would be imported as: from catboost import CatBoostRegressor

def prepare_stock_data(data):
    """
    Prepare stock data for machine learning models
    """
    df = pd.DataFrame(data)
    
    # Feature engineering
    df['price_change'] = df['close'].pct_change()
    df['volume_change'] = df['volume'].pct_change()
    df['high_low_ratio'] = df['high'] / df['low']
    df['price_volume_ratio'] = df['close'] / df['volume']
    
    # Moving averages
    df['ma_5'] = df['close'].rolling(window=5).mean()
    df['ma_10'] = df['close'].rolling(window=10).mean()
    df['ma_20'] = df['close'].rolling(window=20).mean()
    
    # Technical indicators
    df['rsi'] = calculate_rsi(df['close'])
    df['macd'] = calculate_macd(df['close'])
    
    # Remove NaN values
    df = df.dropna()
    
    return df

def calculate_rsi(prices, window=14):
    """Calculate Relative Strength Index"""
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_macd(prices, fast=12, slow=26, signal=9):
    """Calculate MACD indicator"""
    ema_fast = prices.ewm(span=fast).mean()
    ema_slow = prices.ewm(span=slow).mean()
    macd = ema_fast - ema_slow
    return macd

def create_features_and_targets(df, prediction_days=30):
    """
    Create feature matrix and target vector for ML models
    """
    features = ['close', 'volume', 'price_change', 'volume_change', 
                'high_low_ratio', 'ma_5', 'ma_10', 'ma_20', 'rsi', 'macd']
    
    X = df[features].values
    y = df['close'].shift(-prediction_days).values
    
    # Remove NaN values from target
    mask = ~np.isnan(y)
    X = X[mask]
    y = y[mask]
    
    return X, y

def train_xgboost_model(X_train, y_train, X_test, y_test):
    """
    Train XGBoost model for stock prediction
    """
    model = xgb.XGBRegressor(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        random_state=42
    )
    
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    
    metrics = {
        'mse': mean_squared_error(y_test, predictions),
        'mae': mean_absolute_error(y_test, predictions),
        'r2': r2_score(y_test, predictions)
    }
    
    return model, predictions, metrics

def train_catboost_model(X_train, y_train, X_test, y_test):
    """
    Train CatBoost model for stock prediction
    Note: This is a placeholder - actual implementation would use CatBoostRegressor
    """
    # Placeholder using RandomForest as CatBoost substitute
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=6,
        random_state=42
    )
    
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    
    metrics = {
        'mse': mean_squared_error(y_test, predictions),
        'mae': mean_absolute_error(y_test, predictions),
        'r2': r2_score(y_test, predictions)
    }
    
    return model, predictions, metrics

def train_voting_regressor(X_train, y_train, X_test, y_test):
    """
    Train Voting Regressor ensemble model
    """
    # Create base models
    rf = RandomForestRegressor(n_estimators=50, random_state=42)
    lr = LinearRegression()
    xgb_model = xgb.XGBRegressor(n_estimators=50, random_state=42)
    
    # Create voting regressor
    voting_reg = VotingRegressor([
        ('rf', rf),
        ('lr', lr),
        ('xgb', xgb_model)
    ])
    
    voting_reg.fit(X_train, y_train)
    predictions = voting_reg.predict(X_test)
    
    metrics = {
        'mse': mean_squared_error(y_test, predictions),
        'mae': mean_absolute_error(y_test, predictions),
        'r2': r2_score(y_test, predictions)
    }
    
    return voting_reg, predictions, metrics

def train_ensemble_model(X_train, y_train, X_test, y_test):
    """
    Train advanced ensemble model combining all approaches
    """
    # Train individual models
    xgb_model, xgb_pred, _ = train_xgboost_model(X_train, y_train, X_test, y_test)
    catboost_model, catboost_pred, _ = train_catboost_model(X_train, y_train, X_test, y_test)
    voting_model, voting_pred, _ = train_voting_regressor(X_train, y_train, X_test, y_test)
    
    # Weighted ensemble predictions
    weights = [0.4, 0.35, 0.25]  # XGBoost, CatBoost, Voting
    ensemble_pred = (weights[0] * xgb_pred + 
                    weights[1] * catboost_pred + 
                    weights[2] * voting_pred)
    
    metrics = {
        'mse': mean_squared_error(y_test, ensemble_pred),
        'mae': mean_absolute_error(y_test, ensemble_pred),
        'r2': r2_score(y_test, ensemble_pred)
    }
    
    return {
        'xgb': xgb_model,
        'catboost': catboost_model,
        'voting': voting_model,
        'weights': weights
    }, ensemble_pred, metrics

def predict_stock_prices(models, X_future, model_type='ensemble'):
    """
    Make predictions using trained models
    """
    if model_type == 'ensemble':
        xgb_pred = models['xgb'].predict(X_future)
        catboost_pred = models['catboost'].predict(X_future)
        voting_pred = models['voting'].predict(X_future)
        
        weights = models['weights']
        predictions = (weights[0] * xgb_pred + 
                      weights[1] * catboost_pred + 
                      weights[2] * voting_pred)
    else:
        predictions = models[model_type].predict(X_future)
    
    return predictions

# Example usage
if __name__ == "__main__":
    # Sample data preparation
    sample_data = {
        'close': np.random.randn(1000).cumsum() + 100,
        'volume': np.random.randint(1000000, 5000000, 1000),
        'high': np.random.randn(1000).cumsum() + 105,
        'low': np.random.randn(1000).cumsum() + 95
    }
    
    # Prepare data
    df = prepare_stock_data(sample_data)
    X, y = create_features_and_targets(df)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train models
    print("Training XGBoost model...")
    xgb_model, xgb_pred, xgb_metrics = train_xgboost_model(X_train, y_train, X_test, y_test)
    print(f"XGBoost R² Score: {xgb_metrics['r2']:.4f}")
    
    print("Training Voting Regressor...")
    voting_model, voting_pred, voting_metrics = train_voting_regressor(X_train, y_train, X_test, y_test)
    print(f"Voting Regressor R² Score: {voting_metrics['r2']:.4f}")
    
    print("Training Ensemble model...")
    ensemble_models, ensemble_pred, ensemble_metrics = train_ensemble_model(X_train, y_train, X_test, y_test)
    print(f"Ensemble R² Score: {ensemble_metrics['r2']:.4f}")
    
    print("Model training completed successfully!")
