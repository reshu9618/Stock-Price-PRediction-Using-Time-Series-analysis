"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Brain, Zap, BarChart } from "lucide-react"

interface ModelComparisonProps {
  symbol: string
  days: string
}

export default function ModelComparison({ symbol, days }: ModelComparisonProps) {
  const [comparisons, setComparisons] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  const models = [
    {
      name: "XGBoost",
      key: "xgboost",
      description: "Gradient boosting framework optimized for speed and performance",
      icon: <Zap className="h-4 w-4" />,
    },
    {
      name: "CatBoost",
      key: "catboost",
      description: "Gradient boosting on decision trees with categorical features support",
      icon: <Brain className="h-4 w-4" />,
    },
    {
      name: "Voting Regressor",
      key: "voting",
      description: "Ensemble method combining multiple regression algorithms",
      icon: <BarChart className="h-4 w-4" />,
    },
    {
      name: "Ensemble",
      key: "ensemble",
      description: "Advanced ensemble combining all models with weighted voting",
      icon: <Brain className="h-4 w-4" />,
    },
  ]

  const runComparison = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/compare-models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol, days: Number.parseInt(days) }),
      })
      const data = await response.json()
      setComparisons(data)
    } catch (error) {
      console.error("Comparison error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Mock comparison data
  const mockComparisons = {
    xgboost: { accuracy: 0.89, mse: 2.45, prediction: 155.3, executionTime: 0.12 },
    catboost: { accuracy: 0.91, mse: 2.12, prediction: 157.85, executionTime: 0.18 },
    voting: { accuracy: 0.87, mse: 2.78, prediction: 154.2, executionTime: 0.25 },
    ensemble: { accuracy: 0.93, mse: 1.89, prediction: 158.75, executionTime: 0.35 },
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Model Performance Comparison</CardTitle>
          <Button onClick={runComparison} disabled={isLoading}>
            {isLoading ? "Running Comparison..." : "Compare All Models"}
          </Button>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {models.map((model) => {
          const performance = mockComparisons[model.key as keyof typeof mockComparisons]

          return (
            <Card key={model.key} className="relative">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {model.icon}
                  {model.name}
                  {model.key === "ensemble" && (
                    <Badge variant="default" className="ml-2">
                      Best
                    </Badge>
                  )}
                </CardTitle>
                <p className="text-sm text-gray-600">{model.description}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Accuracy</p>
                    <p className="text-lg font-semibold text-green-600">{(performance.accuracy * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">MSE</p>
                    <p className="text-lg font-semibold">{performance.mse.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Prediction</p>
                    <p className="text-lg font-semibold text-blue-600">${performance.prediction.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Speed</p>
                    <p className="text-lg font-semibold">{performance.executionTime.toFixed(2)}s</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">Accuracy Score</p>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${performance.accuracy * 100}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
