"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Target, AlertCircle } from "lucide-react"

interface PredictionResultsProps {
  predictions: any
  symbol: string
  model: string
}

export default function PredictionResults({ predictions, symbol, model }: PredictionResultsProps) {
  if (!predictions) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-32">
          <p className="text-gray-500">No predictions available</p>
        </CardContent>
      </Card>
    )
  }

  // Mock prediction data
  const mockPredictions = {
    currentPrice: 150.25,
    predictedPrice: 158.75,
    confidence: 0.87,
    trend: "bullish",
    accuracy: 0.92,
    volatility: 0.15,
    recommendations: [
      { action: "BUY", confidence: 0.85, reason: "Strong upward trend predicted" },
      { action: "HOLD", confidence: 0.75, reason: "Moderate volatility expected" },
    ],
  }

  const priceChange = mockPredictions.predictedPrice - mockPredictions.currentPrice
  const priceChangePercent = (priceChange / mockPredictions.currentPrice) * 100

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Price Prediction */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Price Prediction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-gray-600">Current Price</p>
            <p className="text-2xl font-bold">${mockPredictions.currentPrice}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Predicted Price</p>
            <p className="text-2xl font-bold text-blue-600">${mockPredictions.predictedPrice}</p>
          </div>
          <div className="flex items-center gap-2">
            {priceChange > 0 ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
            <span className={`font-semibold ${priceChange > 0 ? "text-green-600" : "text-red-600"}`}>
              {priceChange > 0 ? "+" : ""}${priceChange.toFixed(2)} ({priceChangePercent.toFixed(2)}%)
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Model Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Model Performance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-gray-600">Model Used</p>
            <Badge variant="outline" className="mt-1">
              {model.toUpperCase()}
            </Badge>
          </div>
          <div>
            <p className="text-sm text-gray-600">Confidence Score</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${mockPredictions.confidence * 100}%` }}
                ></div>
              </div>
              <span className="text-sm font-semibold">{(mockPredictions.confidence * 100).toFixed(1)}%</span>
            </div>
          </div>
          <div>
            <p className="text-sm text-gray-600">Historical Accuracy</p>
            <p className="text-lg font-semibold text-green-600">{(mockPredictions.accuracy * 100).toFixed(1)}%</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Volatility Index</p>
            <p className="text-lg font-semibold">{mockPredictions.volatility.toFixed(3)}</p>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>AI Recommendations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {mockPredictions.recommendations.map((rec, index) => (
            <div key={index} className="border rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <Badge variant={rec.action === "BUY" ? "default" : rec.action === "SELL" ? "destructive" : "secondary"}>
                  {rec.action}
                </Badge>
                <span className="text-sm text-gray-600">{(rec.confidence * 100).toFixed(0)}% confidence</span>
              </div>
              <p className="text-sm text-gray-700">{rec.reason}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
