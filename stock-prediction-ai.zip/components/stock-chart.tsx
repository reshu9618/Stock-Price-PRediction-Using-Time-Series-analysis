"use client"

import { useEffect, useRef } from "react"

interface StockChartProps {
  historicalData: any
  predictions: any
  symbol: string
}

export default function StockChart({ historicalData, predictions, symbol }: StockChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!chartRef.current || !historicalData) return

    const canvas = chartRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Sample data visualization (replace with actual chart library)
    const width = canvas.width
    const height = canvas.height
    const padding = 40

    // Draw axes
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)
    ctx.stroke()

    // Draw sample price line
    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 2
    ctx.beginPath()

    const dataPoints = 50
    for (let i = 0; i < dataPoints; i++) {
      const x = padding + (i / (dataPoints - 1)) * (width - 2 * padding)
      const y = height - padding - Math.random() * (height - 2 * padding)

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    }
    ctx.stroke()

    // Draw predictions if available
    if (predictions) {
      ctx.strokeStyle = "#ef4444"
      ctx.lineWidth = 2
      ctx.setLineDash([5, 5])
      ctx.beginPath()

      const predictionStart = dataPoints * 0.8
      for (let i = 0; i < 10; i++) {
        const x = padding + ((predictionStart + i) / (dataPoints - 1)) * (width - 2 * padding)
        const y = height - padding - Math.random() * (height - 2 * padding)

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }
      ctx.stroke()
      ctx.setLineDash([])
    }

    // Add labels
    ctx.fillStyle = "#374151"
    ctx.font = "12px sans-serif"
    ctx.fillText(`${symbol} Stock Price`, padding, 20)
    ctx.fillText("Time", width / 2, height - 10)

    // Rotate context for y-axis label
    ctx.save()
    ctx.translate(15, height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.fillText("Price ($)", 0, 0)
    ctx.restore()
  }, [historicalData, predictions, symbol])

  return (
    <div className="w-full">
      <canvas ref={chartRef} width={800} height={400} className="w-full h-auto border rounded-lg bg-white" />
      <div className="flex justify-center gap-4 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-4 h-0.5 bg-blue-500"></div>
          <span className="text-sm text-gray-600">Historical Data</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-0.5 bg-red-500 border-dashed"></div>
          <span className="text-sm text-gray-600">Predictions</span>
        </div>
      </div>
    </div>
  )
}
